Auto Vote Minecraft Rating - Chrome Extension

Автоматическое голосование на топах таких как TopCraft, McTOP, MCRate, MinecraftRating, MonitoringMinecraft, FairTop, IonMc, MinecraftServers, ServeurPrive, PlanetMinecraft, TopG, Minecraft-Mp, Minecraft-Server-List, ServerPact, MinecraftIpList и TopMinecraftServers для Minecraft проектов или серверов

Ссылка на рассширение от куда его можно поставить https://chrome.google.com/webstore/detail/auto-vote-minecraft-ratin/mdfmiljoheedihbcfiifopgmlcincadd

Проверено на следующих браузерах:
- Google Chrome
- Opera
- Яндекс Браузер
- Microsoft Edge
- Kiwi Browser

Если хотите скачать и установить расширение с репозитория:
1. скачайте данный репозиторий
2. распакуйте в удобную папку
3. на chrome://extensions/ (это URL) включите режим разработчика (справа сверху)
4. слева сверху должна появиться кнопка "Загрузить распакованное расширение", нажмите на него
5. выберите каталог в который вы распакавывали